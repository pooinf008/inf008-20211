package avaliacao1_wellington;
public class Avaliacao1_Wellington {
    public static void main(String[] args) {
        CorRGB cor1 = new CorRGB();
        
              
    }
    
}
