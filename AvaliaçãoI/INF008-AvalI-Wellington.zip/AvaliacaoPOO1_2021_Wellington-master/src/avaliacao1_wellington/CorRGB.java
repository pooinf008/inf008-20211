package avaliacao1_wellington;

// ATRIBUTOS DA CLASSE CorRGB.

public class CorRGB { 
    private int Red;
    private int Green;
    private int Blue;

// Questão XIII - Atributos que permitam reduzir o número de instancias de cores comuns.   
    public static final CorRGB PRETA = new CorRGB(0, 0, 0);
    public static final CorRGB BRANCA = new CorRGB(255, 255, 255);
    public static final CorRGB RED = new CorRGB(255, 0, 0);
    public static final CorRGB GREEN = new CorRGB(0, 255, 0);
    public static final CorRGB BLUE = new CorRGB(0, 0, 255);

// MÉTODOS DA CLASSE CorRGB.

// MÉTODOS CONSTRUTORES.
// Questão V - 1 Construtor de cópia, que crie uma cor idêntica.
    public CorRGB(CorRGB cor) { 
        this.Red = cor.getR();
        this.Green = cor.getG();
        this.Blue = cor.getB();
    } 
// Questão V - 2 Construtor para criar a cor preta RGB(0,0,0).
    public CorRGB() { 
        this.Red = 0;
        this.Green = 0;
        this.Blue = 0;
    }
// Questão V - 3 Construtor para criar a Cor RGB.
    public CorRGB(int r, int g, int b) { 
        this.setCorRGB(r, g, b);
    }
    
// questão III - Métodos que leem e alteram os valores de RGB (GETs e SETs).
    public int getR() { 
        return Red;
    }
    public int getG() { 
        return Green;
    }
    public int getB() { 
        return Blue;
    }
    public void setCorRGB(int r, int g, int b) {
            this.Red = r;
            this.Green = g;
            this.Blue = r;
    }
    
// Questão IV - Método lê e calcula a luminosidade e truncar para um valor inteiro.
    public int getLuminosidade() { 
        double luminosidade = (this.getR() * 0.3 + this.getG() * 0.59 + this.getB() * 0.11);
        return (int) Math.round(luminosidade); // "Math.round" Método ideal para receber um parâmetro decimal retornar o valor arredondado em inteiro.
    } 

// Questão VI - Método que compara 2 cores se são iguais.
    public void compararCor(CorRGB cor2) { 
        if(this.getR() == cor2.getR() && this.getG() == cor2.getG() && this.getB() == cor2.getB()) {
            System.out.println("As cores sao iguais.");
        }else{
            System.out.println("As cores sao diferentes.");
        }
    } 
    
// Questão IX - Método que gera uma representação String da cor como Hexadecimal.
    public String getHexadecimal() { 
        String hex = "#" + Integer.toHexString(this.getR()) + Integer.toHexString(this.getG()) + Integer.toHexString(this.getB());
        return hex.toUpperCase();
    }
    
// Questão X - Método para clarear, receber o valor e mudar a tonalidade para claro.
    public void clarear(float p){ 
        int r = (int) (this.getR() * (1 + p));
        int g = (int) (this.getG() * (1 + p));
        int b = (int) (this.getB() * (1 + p));
        this.setCorRGB(r, g, b);
    }
    
// Questão XI - Método para escurecer, receber o valor e mudar a tonalidade para escuro.
    public void escurecer(float p){ 
        int r = (int) (this.getR() * (1 - p));
        int g = (int) (this.getG() * (1 - p));
        int b = (int) (this.getB() * (1 - p));
        this.setCorRGB(r, g, b);
    }
    
// Questão XII - Método que retorne uma nova instancia de RGB, igual a cor que recebeu a msg.
    public CorRGB retornaNovaRGB() { 
    CorRGB cor = new CorRGB(this.getR(), this.getG(), this.getB());
    return cor;
    }
}