# AvaliacaoINF008POO
IFBA – Instituto Federal de Educação, Ciência e Tecnologia da Bahia;
Departamento de Ciência da Computação;
Graduação Tecnológica em Análise e Desenvolvimento de Sistemas;
INF008 – Programação Orientada a Objetos;
Prof.: Frederico Jorge Ribeiro Barboza;
Discentes: Camila Marques Vasconcelos Loureiro;
           Verônica Souza Lemos;
           Vitória dos Santos;
Avaliação da disciplina INF 008 Programação Orientada à Objetos 2021.1
