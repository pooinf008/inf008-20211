

public class Principal {

	public static void main(String[] args) {
		
//		RGB cor1 = new RGB(255,10,20);
//		
//		
//		RGB cor2 = new RGB(255,10,20);
//		if (cor1.equals(cor2)) {
////			System.out.println("S�o iguais!");
//		}else {
////			System.out.println("S�o diferentes!");
//		}
//		
//// 		System.out.println(cor1.corRGB());
//		
////		System.out.println(cor2.corRGB());
		
		IMGMapaBid imagem = new IMGMapaBid(4, 4);
		IMGMapaBid fragmento = new IMGMapaBid(2, 2);
		imagem.modificaPixel(3,3, new RGB(111,111,111));
		fragmento.modificaPixel(0,0, new RGB(111,111,111));
		imagem.modificaPixel(2,2, new RGB(222,222,222));
		fragmento.modificaPixel(1,1, new RGB(222,222,222));

		System.out.println("Imagem");
		System.out.println(imagem);
		System.out.println("Fragmento");
		System.out.println(fragmento);
		

		System.out.println(imagem.equals(fragmento));
	}
	

}
