public class IMGMapaBid {
	private RGB[][] pixels;

	// Construtor cor branca
	public IMGMapaBid(int altura, int largura) {
		this.pixels = new RGB[altura][largura];
		for (int i = 0; i < altura; i++) {
			for (int j = 0; j < largura; j++) {
				this.pixels[i][j] = RGB.BRANCO;
			}
		}
	}

	public void setPixels(RGB[][] pixels) {
		this.pixels = pixels;
	}

	public RGB[][] getPixels() {
		return pixels;
	}

	public int getAltura() {
		return this.pixels[0].length;
	}

	public int getLargura() {
		return this.pixels.length;
	}

	@Override
	public boolean equals(Object imagem) {
		IMGMapaBid retornoRotacao = (IMGMapaBid) imagem;
		// Loop para percorrer largura
		for (int i = 0; i < this.getLargura(); i++) {
			// Loop para percorrer altura
			for (int j = 0; j < this.getAltura(); j++) {
				// Loop para rotacionar fragmento
				for (int iB = 0; iB < 3; iB++) {
					System.out.println(retornoRotacao);
					if (this.verificaFragmento((IMGMapaBid) retornoRotacao, i, j)) {
						return true;
					}
					retornoRotacao = retornoRotacao.rotacionaImagem();
				}
			}

		}

		return false;
	}

	@Override
	public String toString() {
		int altura = pixels.length;
		int largura = pixels[0].length;
		String str = "Pixels\n";

		for (int i = 0; i < altura; i++) {
			for (int j = 0; j < largura; j++) {
				str += "[" + this.pixels[i][j].toString() + "]";
				if (j == largura - 1) {
					str += "\n";
				}
			}
		}
		return str;
	}

	// M�todo que cria uma nova imagem com o equivalente em tons de cinza
	public IMGMapaBid tonsCinza(IMGMapaBid nova) {
		int altura = nova.pixels.length;
		int largura = nova.pixels[0].length;

		for (int i = 0; i < altura; i++) {
			for (int j = 0; j < largura; j++) {
				nova.pixels[i][j] = nova.pixels[i][j].corCinza();
			}
		}
		return (nova);
	}

	// M�todo que modifica o pixel de uma imagem dada a posi��o e o pixel
	public void modificaPixel(int altura, int largura, RGB cor) {
		this.pixels[altura][largura] = cor;
	}

	// M�todo de sobrecarga modifica o pixel
	public void modificaPixel(int altura, int largura, int red, int green, int blue) {
		RGB cor = new RGB(red, green, blue);
		this.pixels[altura][largura] = cor;
	}

	public IMGMapaBid rotacionaImagem() {

		// Tamanho imagem
		int altura = this.getAltura();
		int largura = this.getLargura();

		// Rotaciona imagem e retorna
		IMGMapaBid ret = new IMGMapaBid(altura, largura);
		for (int i = 0; i < largura; i++) {
			for (int j = 0; j < altura; j++) {
				ret.pixels[j][largura - i - 1] = this.pixels[i][j];
			}
		}
		return ret;
	}

	private boolean verificaFragmento(IMGMapaBid fragmento, int i, int j) {
		// Checa tamanhos de imagem e fragmento
		if (!(fragmento.getLargura() <= this.getLargura() - i && fragmento.getAltura() <= this.getAltura() - j)) {
			return false;
		}

		// Percorre elementos
		// i = xA largura para busca
		// j = yB altura para busca
		for (int iA = 0, xA = i; iA < fragmento.getLargura(); iA++, xA++) {
			for (int yA = 0, yB = j; yA < fragmento.getAltura(); yA++, yB++) {
				if (!fragmento.pixels[iA][yA].equals(this.pixels[xA][yB]))
					return false;
			}
		}
		return true;
	}
}
