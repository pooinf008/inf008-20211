public class TesteCorRGB{

    public static void main(String[] args) {
        CorRGB cor = new CorRGB(8,9,10);

        cor.statlus();
    }

}